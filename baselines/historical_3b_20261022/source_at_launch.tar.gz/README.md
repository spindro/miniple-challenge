# MiniPLE 146.5M / PLE64

Single GPU next-token training with Muon, sampled softmax, and full-vocabulary validation. The model has 146,496,016 parameters, a 32,768-token vocabulary, 2,048-token context, 18 layers in the exact `GGLLLGLLLGLLLGLLLG` attention pattern, 640 residual width, 3,072 FFN width, 64 PLE channels, and ReLU². Layers 1, 2, 6, 10, 14, and 18 are global. The twelve local attention layers use RoPE and a 256-token window; the six global attention layers use NoPE (no explicit positional encoding) and the full 2,048-token causal context. Input and output embeddings are tied.

Each of the eight query heads in every layer has one learned sink logit, initialized to zero. As in [GPT-OSS](https://github.com/openai/gpt-oss/blob/main/gpt_oss/torch/model.py), its exponential enters the softmax denominator without contributing a value: `output = sum(exp(score_j) * value_j) / (sum(exp(score_j)) + exp(sink_logit))`. Sinks are always visible, including in local attention. The 144 sink parameters use auxiliary AdamW with zero weight decay.

## Entry scripts

| Script | Purpose |
|---|---|
| `scripts/install.sh` | Create the tested CUDA environment. |
| `scripts/train.sh` | Prepare data if needed, wait for the selected GPU, train, validate, log, and checkpoint. |
| `scripts/debug.sh` | Check dependencies, GPU, model configuration, and prepared data. |
| `scripts/evaluate.py` | Score a checkpoint on zero-shot HellaSwag, PIQA, ARC-Easy, and ARC-Challenge. |
| `scripts/generate.py` | Generate continuations with BF16 KV caching, compiled decoding, and CUDA graphs. |

The Python modules are `model.py`, `attention_sinks.py`, `inference.py`, `muon.py`, `sampled_softmax.py`, `train.py`, `prepare_data.py`, and `tokenizer_utils.py`. `attention_sinks.py` implements the sink normalization and gradients for FlashAttention and portable SDPA. `inference.py` provides the CUDA generation runtime. `train.py` contains the training and validation loop; `prepare_data.py` packs the corpus. `requirements.txt` lists the portable dependencies. `requirements-eval.txt` adds the pinned benchmark harness only when needed.

## Install

On Linux x86_64 with Python 3.12 and a working NVIDIA driver:

```bash
bash scripts/install.sh
```

This installs PyTorch 2.8.0 with CUDA 12.8, Liger 0.8.4, and the FlashAttention 2.8.3.post1 wheel for Python 3.12/PyTorch 2.8. If that exact FlashAttention wheel is unavailable, install a CUDA 12.8 toolkit and compiler compatible with PyTorch, then build it:

```bash
source .venv/bin/activate
python -m pip install packaging ninja psutil einops
export CUDA_HOME=/usr/local/cuda-12.8
export PATH="$CUDA_HOME/bin:$PATH"
FLASH_ATTENTION_FORCE_BUILD=TRUE MAX_JOBS=4 NVCC_THREADS=2 \
  python -m pip install --no-build-isolation --no-binary=flash-attn flash-attn==2.8.3.post1
```

For CPU development, install a compatible PyTorch build and `pip install -r requirements.txt`; the production launcher requires CUDA.

## Train

```bash
GPU_ID=0 OUT_DIR=runs/my_run bash scripts/train.sh
```

The launcher builds `data/ultrafineweb_6b_two_phase` on first use, using a pinned 32,768-token nanochat tokenizer and streamed Ultra-FineWeb L2 and L3 data. Data preparation may take substantial time and disk space. To use already prepared data, set `DATA_DIR` to its directory. Do not replace that directory while resuming a checkpoint: training checks its metadata fingerprint.

The 6B-token recipe uses 20 sequences × 2,048 tokens × four accumulation steps (163,840 tokens/update). This preserves the previous effective token batch and data-mixture schedule while doubling context. Prepared packed token streams can be reused. Muon uses peak LR `8e-4` for hidden matrices; auxiliary fused AdamW uses `6e-4`. There is a 20M-token warmup, then a stable LR until 4.2B tokens and linear cooldown to 6B. The batch is BF16 with FlashAttention and Liger fused linear cross entropy. The model is compiled with `max-autotune-no-cudagraphs`; batched Muon update groups are compiled separately. First-use compilation takes time. Keep `TORCHINDUCTOR_CACHE_DIR` and `TRITON_CACHE_DIR` on persistent writable storage to reuse compiled kernels.

Fresh training uses architecture version 2 with `global_nope=True` and learned sinks in every attention head. The checkpoint records the complete per-layer attention pattern. The attention projection contains Q, K, and V only. The completed 8 October checkpoint uses an earlier architecture and requires the `source_at_launch.tar.gz` saved alongside that run; this version rejects incompatible checkpoints. Its validation and benchmark scores describe the earlier architecture. Version 2 needs a new training run.

The 20 × 2,048 × 4 configuration passed a memory check on GPU0's RTX 3090 on 22 October 2026, using real L2 tokens, BF16, FlashAttention, Liger, compiled model/Muon updates, and initialized optimizer state. Activation checkpointing was disabled.

| Softmax | Peak allocated | Peak reserved |
|---|---:|---:|
| 10,240 candidates | 19.16 GiB | 19.33 GiB |
| 14,336 candidates | 19.16 GiB | 19.40 GiB |
| Full vocabulary | 19.49 GiB | 19.67 GiB |

The uncompiled path ran out of memory at batches 20 and 40. Use the compiled launcher for the tested configuration.

Steady-state GPU0 measurements (six timed optimizer updates after warmup, including four accumulation steps, candidate construction, clipping, and Muon/AdamW updates) found:

| Microbatch × context | 10,240-candidate tokens/s | Full-softmax tokens/s | Full-softmax peak reserved |
|---|---:|---:|---:|
| 20 × 2,048 | 86,995 | 76,772 | 19.42 GiB |
| 24 × 2,048 | 87,054 | 76,384 | 23.12 GiB |

Keep microbatch 20: filling more VRAM did not increase training throughput in these checks. Batch 24 also changes the effective token batch and budget rounding; the prepared-data checks still apply. These are short speed measurements on newly initialized v2 weights, excluding compilation, validation, and checkpoint writes.

Data mix:

| Predicted tokens | L2 | L3 QA | L3 Multi-Style |
|---|---:|---:|---:|
| 0–3B | 100% | 0% | 0% |
| 3B–4.2B | 75% | 12.5% | 12.5% |
| 4.2B–6B | 50% | 25% | 25% |

Training uses shared-negative sampled softmax with 10,240 candidates initially and 14,336 later; the cooldown uses full softmax. Validation uses full-vocabulary cross entropy on 128 fixed 2,048-token L2 sequences every 250 updates (262,144 predicted tokens). `metrics.jsonl`, `train.log`, and `latest.pt` are written under `OUT_DIR`. Milestone checkpoints are saved at the data switch and cooldown; `final_l3_mix.pt` is the final checkpoint.

To resume after a stop, use the same output directory and prepared data:

```bash
GPU_ID=0 OUT_DIR=runs/my_run bash scripts/train.sh --resume runs/my_run/latest.pt
```

Run a quick setup check before training:

```bash
DATA_DIR=data/ultrafineweb_6b_two_phase bash scripts/debug.sh
```

The debug script expects prepared data and reports missing files or mismatched token counts. `train.py` performs the same data checks before allocating the model. Only load checkpoints you trust; they contain Python optimizer and RNG state.

## Evaluate a trained checkpoint

```bash
.venv/bin/python -m pip install -r requirements-eval.txt
CUDA_VISIBLE_DEVICES=1 .venv/bin/python scripts/evaluate.py \
  --checkpoint runs/my_run/final_l3_mix.pt \
  --data-dir data/ultrafineweb_6b_two_phase \
  --out runs/my_run/evaluation.json
```

The evaluator uses EleutherAI's pinned task definitions and the same dataset revisions as earlier project runs. It scores choice continuations with full-vocabulary likelihood, zero examples, and the checkpoint's tokenizer. The report includes raw accuracy (`acc`) and choice-length-normalized accuracy (`acc_norm`). Omit `--limit` for reported scores; `--limit 2` is only a quick functional check. `--tasks hellaswag piqa` selects a subset. ARC-Challenge is difficult for a 146M-parameter base model, so read it alongside ARC-Easy and the held-out L2 validation loss.

## Speed features

The attention Q/K/V projection is fused; each layer's PLE is split once with `unbind(dim=2)`. FlashAttention handles local and global attention. The sink adapter uses the pinned FlashAttention 2.8.3.post1 forward/backward operators with an augmented log-sum-exp; it does not allocate quadratic attention scores on CUDA or require a patched wheel. Liger avoids allocating full token-by-vocabulary logits. Sampled softmax projects only candidate output rows before cooldown. `torch.compile` fuses the decoder's elementwise work. Muon batches matrices by shape and compiles its update; auxiliary AdamW uses fused CUDA kernels. Data files are memory mapped, transfers can be pinned, loss accumulation stays on the GPU, and gradients are reset with `set_to_none=True`.

## Generate text

After training a v2 checkpoint:

```bash
CUDA_VISIBLE_DEVICES=0 OMP_NUM_THREADS=4 TORCHINDUCTOR_COMPILE_THREADS=4 \
  .venv/bin/python scripts/generate.py \
  --checkpoint runs/my_run/final_l3_mix.pt \
  --data-dir data/ultrafineweb_6b_two_phase \
  --prompt "The most important discovery was" --max-new-tokens 128
```

The runtime stores inference weights in BF16, caches K/V in all layers, applies local RoPE inside FlashAttention's cache kernel, and preserves global NoPE and the learned sinks. Only the final hidden position is projected to the vocabulary. Single-token decoding and fixed-size prompt chunks are compiled with full-graph tracing; arbitrary short prompt tails run eagerly to avoid compiling every prompt length. An operator wrapper describes FlashAttention's cache mutations to the compiler. A CUDA graph replays the decoder, sampling, and next-token feedback without a CPU read per token. No additional packages or patched CUDA sources are needed beyond the installation above.

Use batch 1 for single-request latency. Increase `--batch-size` for total throughput across independent continuations of the same prompt; total tokens/s and tokens/s per sequence are reported separately, including prompt processing and excluding initial compilation/capture. `--temperature 0` selects greedy decoding. Prompt plus continuation must fit 2,048 tokens. Generation computes a fixed token count and trims each displayed continuation at the first document delimiter. This minimal runtime requires equal prompt lengths; it does not implement a serving queue or continuous batching.

KV storage is 18 MiB per sequence at a 2,048-token cache capacity, plus approximately 279 MiB of BF16 weights and additional space for activations, CUDA-graph buffers, and CUDA workspaces. For large batches, use `--prefill-chunk-size 128` to bound temporary prompt-processing activations. `--no-compile` and `--no-cuda-graph` are available for debugging. A generator can be reused across requests with the same batch size and sampling settings so compilation/capture costs are paid once.

Warm GPU0 speed checks on 22 October 2026 used the full v2 architecture with random weights, BF16, greedy decoding, a 512-token prompt, and 128 generated tokens. Each cache retained capacity for 2,048 tokens. Prompt chunks were 512 tokens at batches 1/32 and 128 tokens at batches 256/1,024. The table averages three timed requests and excludes compilation, capture, and first-request warmup:

| Batch | Total tokens/s including prompt processing | Total decode tokens/s | Decode tokens/s per sequence | Peak reserved |
|---:|---:|---:|---:|---:|
| 1 | 1,064 | 1,117 | 1,117 | 0.38 GiB |
| 32 | 11,491 | 13,448 | 420 | 1.46 GiB |
| 256 | 19,191 | 25,642 | 100 | 5.97 GiB |
| 1,024 | 20,494 | 27,796 | 27 | 22.90 GiB |

Batch 1,024 was the largest tested. Batch 256 delivered about 94% of its end-to-end throughput with much lower per-sequence latency and memory use. Single-sequence uncached BF16 eager generation measured about 59 tokens/s on the same prompt/output lengths. Compiling prompt processing raised batch-1,024 end-to-end throughput from 16,460 to 20,494 tokens/s. Longer prompts and stochastic sampling change these rates. These speed checks do not measure model quality.

Cached logits were checked against full-prefix decoding through the 2,048-token boundary with nonzero residual projections and learned sinks. Compiled training/optimizer updates, repeated generation requests, greedy feedback, and CUDA-graph sampling also passed functional checks. Measurements and verification summaries are saved in `runs/window_fit_20261022/`; profiling scripts are not part of the source distribution.

The model is intended for pretraining and research. It is not instruction tuned.
